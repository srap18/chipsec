# Security Policy

## Supported Versions

Support is only provided for the latest version: https://github.com/chipsec/chipsec/releases/latest

## Reporting a Vulnerability

Please use the security tab here on GitHub: https://github.com/chipsec/chipsec/security/advisories/new
